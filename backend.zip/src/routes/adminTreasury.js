import { Router } from 'express';
import Transaction from '../models/Transaction.js';
import { createWithdrawal } from '../services/vitaService.js';

const router = Router();

// GET /api/admin/treasury/pending
// Lista transacciones que requieren acción manual (tesorería)
router.get('/pending', async (req, res) => {
    try {
        const pending = await Transaction.find({
            status: { $in: ['pending_verification', 'pending_manual_payout'] }
        })
            .sort({ createdAt: 1 })
            .populate('createdBy', 'name email');

        res.json({ ok: true, transactions: pending });
    } catch (error) {
        res.status(500).json({ ok: false, error: 'Error al cargar tesorería.' });
    }
});

// PUT /api/admin/treasury/:id/approve-deposit
// Admin confirma que el depósito/entrada fue recibido y, si hay payload guardado,
// ejecuta el envío real (withdrawal) en Vita.
router.put('/:id/approve-deposit', async (req, res) => {
    try {
        const tx = await Transaction.findById(req.params.id);
        if (!tx) return res.status(404).json({ ok: false, error: 'Transacción no encontrada.' });

        if (tx.status !== 'pending_verification') {
            return res.status(409).json({
                ok: false,
                error: `Estado inválido para aprobar depósito: ${tx.status}`
            });
        }

        if (!tx.withdrawalPayload) {
            return res.status(422).json({
                ok: false,
                error: 'No existe payload guardado para ejecutar el envío. Revisa la creación de la transacción.'
            });
        }

        // Ejecutar envío real en Vita
        tx.status = 'processing';
        await tx.save();

        const vitaRes = await createWithdrawal(tx.withdrawalPayload);
        tx.vitaResponse = vitaRes;
        tx.status = 'processing'; // IPN debe marcar succeeded/failed
        await tx.save();

        res.json({
            ok: true,
            message: 'Depósito aprobado. Envío iniciado en Vita.',
            vita: vitaRes
        });
    } catch (error) {
        const vitaErr = error?.response?.data;
        if (error?.response?.status) {
            return res.status(error.response.status).json({
                ok: false,
                error: 'Vita API Error',
                details: vitaErr
            });
        }

        res.status(500).json({ ok: false, error: 'Error al aprobar depósito.' });
    }
});

// PUT /api/admin/treasury/:id/complete-payout
// Admin confirma que ya transfirió el dinero en el off-ramp manual
router.put('/:id/complete-payout', async (req, res) => {
    try {
        const tx = await Transaction.findById(req.params.id);
        if (!tx) return res.status(404).json({ ok: false, error: 'Transacción no encontrada.' });

        if (tx.status !== 'pending_manual_payout') {
            return res.status(409).json({
                ok: false,
                error: `Estado inválido para completar pago: ${tx.status}`
            });
        }

        const { proofUrl } = req.body || {};
        if (proofUrl) tx.proofOfPayment = proofUrl;

        tx.status = 'succeeded';
        await tx.save();

        res.json({ ok: true, message: 'Pago marcado como completado.' });
    } catch (error) {
        res.status(500).json({ ok: false, error: 'Error al completar pago.' });
    }
});

export default router;
