// backend/src/routes/paymentOrders.js
import { Router } from 'express';
import { createPaymentOrder, getPaymentMethods, executeDirectPayment } from '../services/vitaService.js';

const router = Router();

// GET /api/payment-orders/methods/:country
// Obtiene los métodos reales desde Vita Wallet
router.get('/methods/:country', async (req, res) => {
  try {
    const { country } = req.params;
    const methods = await getPaymentMethods(country);
    return res.json({ ok: true, data: methods });
  } catch (e) {
    console.error('[paymentOrders] Error obteniendo métodos:', e.message);
    return res.status(500).json({ ok: false, error: 'Error al obtener métodos de pago' });
  }
});

// POST /api/payment-orders (Paso 1 del pago: Crear la Orden)
// backend/src/routes/paymentOrders.js
router.post('/', async (req, res, next) => {
  try {
    const { amount, country, orderId } = req.body || {};
    if (amount === undefined || amount === null || !country || !orderId) {
      return res.status(400).json({ ok: false, error: 'Faltan datos requeridos.' });
    }

    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    const successRedirectUrl = `${frontendUrl}/payment-success?orderId=${encodeURIComponent(orderId)}`;

    const payload = {
      amount: Math.round(Number(amount)),
      country_iso_code: String(country).toUpperCase().trim(),
      issue: `Pago de remesa #${orderId}`,
      success_redirect_url: successRedirectUrl,
    };

    const response = await createPaymentOrder(payload);

    // Normaliza por si vitaService devuelve data o axios response
    const raw = response?.data ?? response;

    // Log útil (sin secretos) — AHORA sí se ejecuta
    console.log('[payment-orders] Vita response keys:', Object.keys(raw || {}));

    const vitaCheckoutBase = process.env.VITA_CHECKOUT_BASE_URL;
    const id = raw?.id || raw?.data?.id;
    const publicCode = raw?.attributes?.public_code || raw?.data?.attributes?.public_code;

    // si Vita no entrega una url, la construimos
    let checkoutUrl =
      raw?.checkout_url ||
      raw?.redirect_url ||
      raw?.url ||
      raw?.checkoutUrl ||
      raw?.redirectUrl;

    if (!checkoutUrl && vitaCheckoutBase && id && publicCode) {
      checkoutUrl = `${vitaCheckoutBase.replace(/\/$/, '')}/checkout?id=${encodeURIComponent(id)}&public_code=${encodeURIComponent(publicCode)}`;
    }

    return res.status(201).json({
      ok: true,
      checkoutUrl,
      raw,
    });
  } catch (e) {
    return next(e);
  }
});

// POST /api/payment-orders/:vitaOrderId/execute (Paso 2 del pago: Ejecutar Directo)
router.post('/:vitaOrderId/execute', async (req, res, next) => {
  try {
    const { vitaOrderId } = req.params;
    const { payment_data } = req.body || {}; // Datos del formulario (nombre, email, etc.)

    if (!payment_data) {
      return res.status(400).json({ ok: false, error: 'Faltan datos de pago (payment_data).' });
    }

    // OJO: tu vitaService actual espera (data) o (payload) según implementación.
    // Como tú lo estabas llamando executeDirectPayment(vitaOrderId, payment_data),
    // lo mantenemos, pero debe coincidir con la firma de vitaService.
    const response = await executeDirectPayment({ uid: vitaOrderId, ...payment_data });

    return res.json({ ok: true, data: response });
  } catch (e) {
    console.error('❌ Error en pago directo:', e?.message || e);

    // Manejo específico de errores de Vita (422, etc.)
    if (e.response) {
      return res.status(e.response.status).json({
        ok: false,
        error: 'Error de Vita Wallet',
        details: e.response.data,
      });
    }

    return next(e);
  }
});

export default router;