// backend/src/services/vitaClient.js
import axios from 'axios';
import crypto from 'crypto';
import { vita } from '../config/env.js';

// Elimina undefined/null recursivamente
function deepClean(value) {
  if (value === undefined || value === null) return undefined;
  if (Array.isArray(value)) return value.map(deepClean).filter(v => v !== undefined);

  if (value && typeof value === 'object' && value.constructor === Object) {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      const cleaned = deepClean(v);
      if (cleaned !== undefined) out[k] = cleaned;
    }
    return out;
  }
  return value;
}

// sorted_request_body:
// keys top-level ordenadas + concat key+value (sin separadores)
// objects/arrays: JSON.stringify(value)
function buildSortedRequestBody(bodyObj) {
  if (!bodyObj || typeof bodyObj !== 'object') return '';

  const keys = Object.keys(bodyObj).sort();
  let out = '';

  for (const k of keys) {
    const v = bodyObj[k];
    if (v === undefined || v === null) continue;

    if (typeof v === 'object') out += `${k}${JSON.stringify(v)}`;
    else out += `${k}${String(v)}`;
  }

  return out;
}

function hmacSha256Hex(secret, msg) {
  return crypto.createHmac('sha256', secret).update(msg, 'utf8').digest('hex');
}

// vita.baseURL debe apuntar al Base URL de Business API:
// stage: https://api.stage.vitawallet.io/api/businesses
// prod:  https://api.vitawallet.io/api/businesses
const client = axios.create({
  baseURL: vita.baseURL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

client.interceptors.request.use((config) => {
  const xLogin = String(vita.login || '').replace(/\s+/g, '');
  const xApiKey = String(vita.transKey || '').replace(/\s+/g, '');
  const secretKey = String(vita.secret || '').replace(/\s+/g, '');

  if (!xLogin || !xApiKey || !secretKey) {
    throw new Error('Missing Vita credentials (VITA_LOGIN / VITA_TRANS_KEY / VITA_SECRET)');
  }

  const xDate = new Date().toISOString();
  const url = String(config.url || '').toLowerCase();
  const isBusinessUsers = url.includes('/business_users');

  let bodyObj = undefined;
  let bodyString = '';

  const method = String(config.method || 'GET').toUpperCase();
  const hasRequestBody =
    method !== 'GET' &&
    config.data !== undefined &&
    config.data !== null &&
    config.data !== '';

  if (hasRequestBody) {
    let raw = config.data;

    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch { raw = {}; }
    }
    if (!raw || typeof raw !== 'object') raw = {};

    // ✅ NO canonicalizar profundo
    bodyObj = deepClean(raw) || {};
    bodyString = JSON.stringify(bodyObj);

    config.data = bodyString;
    config.transformRequest = [(data) => data];
  }

  const hasBody = Boolean(bodyString && bodyString !== '{}' && bodyString !== '');

  const signatureBody = hasBody
    ? (isBusinessUsers ? bodyString : buildSortedRequestBody(bodyObj))
    : '';

  const signatureBase = `${xLogin}${xDate}${signatureBody}`;
  const signature = hmacSha256Hex(secretKey, signatureBase);

  config.headers = config.headers || {};
  config.headers['x-date'] = xDate;
  config.headers['x-login'] = xLogin;
  config.headers['x-api-key'] = xApiKey;
  config.headers['x-trans-key'] = xApiKey;
  config.headers['Authorization'] = `V2-HMAC-SHA256, Signature: ${signature}`;

  if (process.env.VITA_DEBUG_SIGNATURE === 'true') {
    console.log(`[vitaClient] ${String(config.method || 'GET').toUpperCase()} ${config.url}`);
    console.log(`[vitaClient] mode=${isBusinessUsers ? 'RAW_JSON business_users' : 'SORTED_KV'} hasBody=${hasBody}`);
    console.log(`[vitaClient] bodyLen=${bodyString.length} sigBodyLen=${signatureBody.length}`);

    const sorted = hasBody ? buildSortedRequestBody(bodyObj) : '';
    console.log(`[vitaClient] sorted_request_body(0..300): ${sorted.slice(0, 300)}`);
    console.log(`[vitaClient] bodyString(0..300): ${bodyString.slice(0, 300)}`);

    try {
      const parsed = bodyString ? JSON.parse(bodyString) : {};
      console.log('[vitaClient] types:', {
        amount: typeof parsed.amount,
        bank_code: typeof parsed.bank_code,
        currency: typeof parsed.currency,
      });
    } catch { }

  }

  return config;
});

client.interceptors.response.use(
  (res) => res,
  (error) => {
    const status = error?.response?.status;
    const data = error?.response?.data;
    const url = error?.config?.url;

    console.error(`❌ [vitaClient] Error ${status || 'NO_STATUS'} on ${url || 'NO_URL'}`);
    console.error('>> Vita Response:', JSON.stringify(data));
    return Promise.reject(error);
  }
);

export { client };